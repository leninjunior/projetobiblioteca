package com.example.gerenciadodebiblioteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GerenciadodebibliotecaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GerenciadodebibliotecaApplication.class, args);
	}

}
