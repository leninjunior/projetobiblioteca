package com.example.gerenciadodebiblioteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerenciadodebibliotecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
